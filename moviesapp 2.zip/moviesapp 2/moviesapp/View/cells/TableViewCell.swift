//
//  TableViewCell.swift
//  moviesapp
//
//  Created by Ashim Dauren  on 23.04.2021.
//

import UIKit
import Kingfisher

class TableViewCell: UITableViewCell {
    public static let identifier = "TableViewCell"
    @IBOutlet private weak var containerRating: UIView!
    @IBOutlet private weak var ratingLbl: UILabel!
    @IBOutlet private weak var titleLbl: UILabel!
    @IBOutlet private weak var releaseLbl: UILabel!
    @IBOutlet private weak var posterImg: UIImageView!
    @IBOutlet private weak var favBttn: UIButton!
    
    private let context = CoreDataManager.shared.persistentContainer.viewContext
    public var movie: MovieModel.Movie?{
        didSet{
            if let movie = movie{
                let posterURL = URL(string: "https://image.tmdb.org/t/p/w500" + (movie.poster ?? ""))
                posterImg.kf.setImage(with: posterURL)
                titleLbl.text = movie.title
                ratingLbl.text = "\(movie.rating)"
                releaseLbl.text = movie.releaseDate
                
                if let _ = MovieEntity.findMovie(with: movie.id, context: context){
                        favBttn.setImage(UIImage(systemName: "star.fill"), for: .normal)
                    }else{
                        favBttn.setImage(UIImage(systemName: "star"), for: .normal)
                    }
            }
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        containerRating.layer.cornerRadius = 20
        containerRating.layer.masksToBounds = true
        posterImg.layer.cornerRadius = 12
        posterImg.layer.masksToBounds = true
    }

    @IBAction func FavBttnSet(){
        if let movie = movie{
            if let _ = MovieEntity.findMovie(with: movie.id, context: context){
                favBttn.setImage(UIImage(systemName: "star"), for: .normal)
                CoreDataManager.shared.deleteMovie(with: movie.id)
            }else{
                favBttn.setImage(UIImage(systemName: "star.fill"), for: .normal)
                CoreDataManager.shared.addMovie(movie)
            }
        }
    }
    
}
