//
//  CoreDataManager.swift
//  moviesapp
//
//  Created by Ashim Dauren on 21.05.2021.
//

import Foundation
import CoreData

class CoreDataManager{
    static let shared = CoreDataManager()
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "LocalDBModel")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    private init(){}
    
    func save(){
        let context = persistentContainer.viewContext
        do{
            try context.save()
        }catch{
            print("Error occured!")
        }
    }
    func allMovies() -> [MovieModel.Movie]{
        let context = persistentContainer.viewContext
        let request: NSFetchRequest<MovieEntity> = MovieEntity.fetchRequest()
        let movies = try? context.fetch(request)
        
        
        return movies?.map({MovieModel.Movie(movie: $0)}) ?? []
    }
    func addMovie(_ movie: MovieModel.Movie){
        let context = persistentContainer.viewContext
        context.perform {
            let newMovie =  MovieEntity(context: context)
            newMovie.id = Int64(movie.id)
            newMovie.image = movie.poster
            newMovie.rating = movie.rating
            newMovie.release_date = movie.releaseDate
            newMovie.title = movie.title
        }
        save() 
    }
    func addMovie(_ movie: Detail){
        let context = persistentContainer.viewContext
        if let id = movie.id{
            context.perform {
                let newMovie =  MovieEntity(context: context)
                newMovie.id = Int64(id)
                newMovie.image = movie.poster
                newMovie.rating = movie.rating ?? 0
                newMovie.release_date = movie.releaseDate
                newMovie.title = movie.title
            }
        }
        save()
    }
    func deleteMovie(with id: Int){
        let context = persistentContainer.viewContext
        if let movie = MovieEntity.findMovie(with: id, context: context){
            context.delete(movie)
        }
        save()
    }
}
