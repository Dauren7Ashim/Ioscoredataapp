//
//  MovieDetailsViewController.swift
//  moviesapp
//
//  Created by Ashim Dauren on 25.04.2021.
//

import UIKit
import Alamofire
import Kingfisher
class MovieDetailsViewController: UIViewController {
    public var movieId: Int?
    var details: Detail?
    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var releaseDateLabel: UILabel!
    @IBOutlet weak var posterImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var favoriteBttn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        containerView.layer.cornerRadius = 20
        containerView.layer.masksToBounds = true
        fetchData()
        updateView()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let context = CoreDataManager.shared.persistentContainer.viewContext
        if let movieId = movieId{
            if let _ = MovieEntity.findMovie(with: movieId, context: context){
                favoriteBttn.setImage(UIImage(systemName: "star.fill"), for: .normal)
            }else{
                favoriteBttn.setImage(UIImage(systemName: "star"), for: .normal)
            }
        }
    }
    @IBAction func setFavorite(){
        let context = CoreDataManager.shared.persistentContainer.viewContext
        if let movieId = movieId{
            if let _ = MovieEntity.findMovie(with: movieId, context: context){
                favoriteBttn.setImage(UIImage(systemName: "star"), for: .normal)
                CoreDataManager.shared.deleteMovie(with: movieId)
            }else{
                if var details = details{
                favoriteBttn.setImage(UIImage(systemName: "star.fill"), for: .normal)
                details.id = movieId
                    CoreDataManager.shared.addMovie(details)
            }
            }
        }

    }
    func fetchData(){
        if let movieid = movieId{
        let URL = "https://api.themoviedb.org/3/movie/\(movieid)?api_key=51e0a7df46f6034e9ad07515d69ac046"
        AF.request(URL, method: .get).responseJSON { (response) in
            switch response.result{
            case .success:
                if let data = response.data{
                    do{
                        let detailsJSON = try JSONDecoder().decode(Detail.self, from: data)
                        self.details = detailsJSON
                        self.updateView()
                    
                    }catch{
                        print(error)
                    }
                }
            case .failure:
                print("Some error occured!")
            }
        }
    }
    }
    func updateView(){
        if let details = details{
            let posterURL = URL(string: "https://image.tmdb.org/t/p/w500" + (details.poster ?? ""))
            titleLabel.text = details.title
            descLabel.text = details.description
            ratingLabel.text = "\(details.rating ?? 0)"
            posterImage.kf.setImage(with: posterURL)
            releaseDateLabel.text = details.releaseDate
            navigationItem.title = details.title
        }
    }
}
