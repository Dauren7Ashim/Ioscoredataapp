//
//  FavoriteMoviesViewController.swift
//  moviesapp
//
//  Created by Ashim Dauren on 21.05.2021.
//

import UIKit

class FavoriteMoviesViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    private var movie: [MovieModel.Movie] = [MovieModel.Movie](){
        didSet{
            tableView.reloadData()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: TableViewCell.identifier, bundle: nil), forCellReuseIdentifier: TableViewCell.identifier)
        tableView.separatorStyle = .none
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        movie = CoreDataManager.shared.allMovies()
    }
    

}
extension FavoriteMoviesViewController:UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        movie.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: TableViewCell.identifier, for: indexPath) as! TableViewCell
        cell.movie = movie[indexPath.row]
        return cell
    }
    
    
}
