//
//  ViewController.swift
//  moviesapp
//
//  Created by Ashim Dauren on 23.04.2021.
//

import UIKit
import Alamofire
class ViewController: UIViewController {
    private var movies: [MovieModel.Movie] = [MovieModel.Movie](){
        didSet{
            tableView.reloadData()
        }
    }
    private var pageNumber: Int = 1
    private let trendingMoviesURL: String = "https://api.themoviedb.org/3/trending/movie/week?api_key=51e0a7df46f6034e9ad07515d69ac046"
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UINib(nibName: TableViewCell.identifier, bundle: nil), forCellReuseIdentifier: TableViewCell.identifier)
        getTrendingMovies()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }

}
extension ViewController{
    private func getTrendingMovies(_ page: Int? = nil){
        var params: [String:Any] = [:]
        if let page = page{
            params["page"] = page
        }
        
        AF.request(trendingMoviesURL, method: .get, parameters: params).responseJSON { (response) in
            switch response.result{
            case .success:
                if let data = response.data{
                    do{
                    let movieJSON = try JSONDecoder().decode(MovieModel.self, from: data)
                        self.movies += movieJSON.movies
                    }catch{
                        print(error)
                    }
                }
                
            case .failure:
                print("Failed to upload movies")
            }
        }
    }
}
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    let vc = storyboard?.instantiateViewController(identifier: "MovieDetailsViewController") as! MovieDetailsViewController
        vc.movieId = movies[indexPath.row].id
        navigationController?.pushViewController(vc, animated: true)
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffSet = scrollView.contentOffset.y
        let maximumOffSet = scrollView.contentSize.height - scrollView.frame.height
        let deltaOffSet = maximumOffSet - currentOffSet
        if deltaOffSet <= 10 && currentOffSet < 200{
            pageNumber+=1
            getTrendingMovies(pageNumber)
        }
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: TableViewCell.identifier, for: indexPath) as! TableViewCell
        cell.movie = movies[indexPath.row]
        return cell
    }
    
    
}
